create
  definer = root@localhost function udf_stadium_players_count(stadium_name varchar(30)) returns int
BEGIN
declare player_count int;
set player_count := (select count(p.id) as `count` from players p join 
teams ts on
ts.id = p.team_id join stadiums st on
ts.stadium_id = st.id
where st.name = stadium_name);
RETURN player_count;
END;

